package com.relatafacil.relatafacil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.relatafacil.relatafacil.model.RelataModel;

public interface RelataRepository extends JpaRepository <RelataModel, Long> {

}
