package com.relatafacil.relatafacil.dto;

public record RelataDTO(String nomeRelatorio, String nomeSetor, String nomeCriador, String urlImagem, String texto) {

}
